package JSonParser;

import com.google.gson.Gson;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;

public class MaleNames {
    public String[] getData() {
        return data;
    }

    public void setData(String[] data) {
        this.data = data;
    }

    String [] data;


}
