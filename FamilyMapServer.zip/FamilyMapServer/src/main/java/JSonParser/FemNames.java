package JSonParser;


public class FemNames {
    public String[] getData() {
        return data;
    }

    public void setData(String[] data) {
        this.data = data;
    }

    String [] data;

}
