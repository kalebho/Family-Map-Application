package JSonParser;

public class SirNames {
    public String[] getData() {
        return data;
    }

    public void setData(String[] data) {
        this.data = data;
    }

    String [] data;

    }
