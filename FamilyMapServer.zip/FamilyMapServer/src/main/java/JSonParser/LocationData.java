package JSonParser;

public class LocationData {
    public Location[] getData() {
        return data;
    }

    public void setData(Location[] data) {
        this.data = data;
    }

    private Location[] data;

}
